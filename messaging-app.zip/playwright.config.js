const config = {
	webServer: {
		command: 'npm run dev',
		port: 443
	}
};

export default config;
