<script lang="ts">
</script>

<div class="hero min-h-screen bg-base-200">
	<div class="text-center hero-content">
		<div class="max-w-md">
			<h1 class="text-5xl font-bold">Chat does not exist</h1>
			<p class="py-6">Try another chat</p>

			<br />
		</div>
	</div>
</div>
