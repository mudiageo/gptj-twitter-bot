export const CACHE_NAME = 'app-cache';
